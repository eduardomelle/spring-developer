package com.example.vanilla;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VanillaApplicationTests {

	@Test
	void contextLoads() {
	}

}
